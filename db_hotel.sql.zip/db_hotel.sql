-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Sam 27 Janvier 2018 à 00:28
-- Version du serveur :  5.6.15-log
-- Version de PHP :  5.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `db_hotel`
--

-- --------------------------------------------------------

--
-- Structure de la table `activite`
--

CREATE TABLE IF NOT EXISTS `activite` (
  `id_act` int(15) NOT NULL AUTO_INCREMENT,
  `titre_activite` varchar(50) NOT NULL,
  `image_act` varchar(50) NOT NULL,
  `description_act` text NOT NULL,
  PRIMARY KEY (`id_act`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `activite`
--

INSERT INTO `activite` (`id_act`, `titre_activite`, `image_act`, `description_act`) VALUES
(1, 'Parc', 'ST2', 'Visiter le parc national de la comoe'),
(2, 'Pont de liane', 'ST3', 'Visiter le pont de liane de Man'),
(3, 'Plage Assinie', 'ST4', 'Visiter la plage a Assinie'),
(5, 'Cascade de man', 'ST9', 'Vister les cascade de Man'),
(6, 'Lac au Caiman', 'ST7', 'Visiter le Lac au Caiman'),
(7, 'Basilique Notre Dame de la paix de Yamoussoukro', 'TS', 'Visiter la basilique de Yamoussoukro');

-- --------------------------------------------------------

--
-- Structure de la table `chambre`
--

CREATE TABLE IF NOT EXISTS `chambre` (
  `id_cham` int(15) NOT NULL AUTO_INCREMENT,
  `titre_cham` varchar(50) NOT NULL,
  `image_cham` varchar(50) NOT NULL,
  `prix_cham` int(15) NOT NULL,
  PRIMARY KEY (`id_cham`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `chambre`
--

INSERT INTO `chambre` (`id_cham`, `titre_cham`, `image_cham`, `prix_cham`) VALUES
(1, 'Chambre avec une decoration retro', 'AM6', 60000),
(2, 'Chambre spacieuse avec vue sur la ville', 'AM8', 75000),
(3, 'Chambre avec decoration sobre', 'EC', 40000),
(4, 'Chambre Noir Blanc', 'c4noir', 60000),
(6, 'Chambre Loft', 'c3loft', 80000),
(7, 'Chambre spacieuse jacuzzi', 'c1', 90000),
(9, 'Chambre avec vue sur la mer', 'c8', 70000),
(10, 'Chambre avec vue sur la mer', 'c7', 60000);

-- --------------------------------------------------------

--
-- Structure de la table `chambre_temp`
--

CREATE TABLE IF NOT EXISTS `chambre_temp` (
  `id_temp` int(15) NOT NULL,
  `nom_temp` varchar(100) NOT NULL,
  `prenoms_temp` varchar(200) NOT NULL,
  `date_arrive_temp` date NOT NULL,
  `date_depart_temp` date NOT NULL,
  `prix_temp` int(20) NOT NULL,
  `nbre_chambre` int(10) NOT NULL,
  `nbre_person` int(20) NOT NULL,
  `contact_temp` varchar(25) NOT NULL,
  PRIMARY KEY (`id_temp`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Contenu de la table `chambre_temp`
--

INSERT INTO `chambre_temp` (`id_temp`, `nom_temp`, `prenoms_temp`, `date_arrive_temp`, `date_depart_temp`, `prix_temp`, `nbre_chambre`, `nbre_person`, `contact_temp`) VALUES
(1, 'Moise', 'Blair', '2018-01-29', '2018-02-02', 60000, 2, 3, '01254789'),
(2, 'Elle', 'Ko', '2018-01-24', '2018-01-27', 75000, 2, 4, '01235647'),
(3, 'Elle', 'Ko', '2018-01-24', '2018-01-27', 75000, 2, 4, '01235647'),
(4, 'Elle', 'Ko', '2018-01-24', '2018-01-27', 75000, 2, 4, '01235647'),
(5, 'KAKI', 'Sisi', '2018-01-25', '2018-01-27', 75000, 1, 2, '02365489'),
(6, 'Loli', 'Gol', '2018-01-24', '2018-01-27', 60000, 2, 2, '89786915'),
(7, 'Moise', 'Gol', '2018-01-25', '2018-01-27', 75000, 2, 2, '89786915'),
(8, 'KAKI', 'Blair', '2018-01-26', '2018-01-30', 75000, 1, 1, '02365489'),
(9, 'Elle', 'Mallot', '2018-01-26', '2018-01-29', 75000, 1, 1, '89786915'),
(10, 'Moise', 'Blair', '2018-01-18', '2018-01-21', 75000, 1, 2, '89786915'),
(11, 'Evilafo', 'Emmanuel', '2018-01-09', '2018-01-11', 75000, 2, 1, '89786915'),
(12108, 'Evilafo', 'Emmanuel', '2018-01-25', '2018-01-30', 75000, 1, 2, '89786915'),
(19285, 'Elle', 'Ko', '2018-01-20', '2018-01-23', 75000, 2, 1, '01254789'),
(32211, 'Moise', 'Blair', '2018-01-18', '2018-01-26', 60000, 1, 1, '01235647'),
(3884, 'Peage', 'ami', '2018-01-17', '2018-01-31', 60000, 3, 3, '22222222'),
(1546, 'yao', 'ami', '2018-01-14', '2018-01-28', 75000, 1, 1, '25647893');

-- --------------------------------------------------------

--
-- Structure de la table `form_activite`
--

CREATE TABLE IF NOT EXISTS `form_activite` (
  `id_formact` int(15) NOT NULL AUTO_INCREMENT,
  `nom_act` varchar(50) NOT NULL,
  `prenom_act` varchar(50) NOT NULL,
  `titre_act` varchar(50) NOT NULL,
  `date_act` date NOT NULL,
  `heure_act` time NOT NULL,
  `nombre_persone` int(10) NOT NULL,
  `contact` int(11) NOT NULL,
  PRIMARY KEY (`id_formact`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19240 ;

--
-- Contenu de la table `form_activite`
--

INSERT INTO `form_activite` (`id_formact`, `nom_act`, `prenom_act`, `titre_act`, `date_act`, `heure_act`, `nombre_persone`, `contact`) VALUES
(19239, 'Elle', 'Blair', 'Plage Assinie', '2018-01-25', '12:00:00', 5, 1236547),
(2535, 'yao', 'yao', 'Pont de liane', '2018-01-06', '12:12:00', 2, 2222222),
(7741, 'yao', 'ami', 'Pont de liane', '2018-01-13', '12:12:00', 3, 56894658);

-- --------------------------------------------------------

--
-- Structure de la table `form_chambre`
--

CREATE TABLE IF NOT EXISTS `form_chambre` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `date_arrivee` date NOT NULL,
  `date_depart` date NOT NULL,
  `prix_cham` int(11) NOT NULL,
  `nombre_chambre` int(10) NOT NULL,
  `nombre_persone` int(10) NOT NULL,
  `contact` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `form_chambre`
--

INSERT INTO `form_chambre` (`id`, `nom`, `prenom`, `date_arrivee`, `date_depart`, `prix_cham`, `nombre_chambre`, `nombre_persone`, `contact`) VALUES
(1, 'Peage', 'Gol', '2018-01-23', '2018-01-27', 60000, 5, 10, 2536987),
(10, 'Peage', 'ami', '2018-01-17', '2018-01-31', 60000, 3, 3, 22222222),
(9, 'Moise', 'Blair', '2018-01-18', '2018-01-26', 60000, 1, 1, 1235647),
(8, 'Ki', 'Gol', '2018-01-11', '2018-02-02', 75000, 2, 3, 1254789),
(7, 'Evilafo', 'Blair', '2018-01-19', '2018-01-27', 75000, 1, 2, 1254789),
(11, 'yao', 'ami', '2018-01-14', '2018-01-28', 75000, 1, 1, 25647893);

-- --------------------------------------------------------

--
-- Structure de la table `form_spa`
--

CREATE TABLE IF NOT EXISTS `form_spa` (
  `id_spa` int(11) NOT NULL AUTO_INCREMENT,
  `nom_spa` varchar(20) NOT NULL,
  `prenom_spa` varchar(20) NOT NULL,
  `sexe_spa` varchar(10) NOT NULL,
  `durabo_spa` int(50) NOT NULL,
  `cont_spa` int(50) NOT NULL,
  PRIMARY KEY (`id_spa`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23589 ;

--
-- Contenu de la table `form_spa`
--

INSERT INTO `form_spa` (`id_spa`, `nom_spa`, `prenom_spa`, `sexe_spa`, `durabo_spa`, `cont_spa`) VALUES
(23588, 'Paege', 'Gol', 'feminin', 3, 2145639),
(15335, 'ki', 'lo', 'F', 2, 2356897);

-- --------------------------------------------------------

--
-- Structure de la table `form_sport`
--

CREATE TABLE IF NOT EXISTS `form_sport` (
  `id_spo` int(11) NOT NULL AUTO_INCREMENT,
  `nom_spo` varchar(52) NOT NULL,
  `prenom_spo` varchar(50) NOT NULL,
  `sexe_spo` varchar(15) NOT NULL,
  `dabonne_spo` int(15) NOT NULL,
  `contact_spo` int(15) NOT NULL,
  PRIMARY KEY (`id_spo`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5013 ;

--
-- Contenu de la table `form_sport`
--

INSERT INTO `form_sport` (`id_spo`, `nom_spo`, `prenom_spo`, `sexe_spo`, `dabonne_spo`, `contact_spo`) VALUES
(5012, 'Kra', 'Binger', 'M', 2, 235689);

-- --------------------------------------------------------

--
-- Structure de la table `restaurant`
--

CREATE TABLE IF NOT EXISTS `restaurant` (
  `id_resto` int(15) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `date_resto` date NOT NULL,
  `heure` time NOT NULL,
  `nombre_pers` int(11) NOT NULL,
  `contacts` int(15) NOT NULL,
  PRIMARY KEY (`id_resto`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20373 ;

--
-- Contenu de la table `restaurant`
--

INSERT INTO `restaurant` (`id_resto`, `nom`, `prenom`, `date_resto`, `heure`, `nombre_pers`, `contacts`) VALUES
(20372, 'paege', 'gol', '2018-01-27', '12:00:00', 2, 235844);

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id_service` int(15) NOT NULL AUTO_INCREMENT,
  `titre_service` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id_service`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `services`
--

INSERT INTO `services` (`id_service`, `titre_service`, `image`, `description`) VALUES
(3, 'Piscine interieur', 'P3', 'Piscine a temperature ambiante et a grande capacite. Rien que pour vous'),
(2, 'Piscine exterieur', 'P15', 'Piscine relaxante et ouvert à bon nombre de personne'),
(1, 'Piscine naturelle', 'P14', 'Source naturellement rechauffer avec des vertus therapeutique'),
(5, 'Salle de reunion grande capacite', 'RE1', 'Salle avec une grande capacite d''accueil et grand public'),
(4, 'salle de reunion privee', 'RE', 'Salle de reunion VIP avec toutes les commodites'),
(6, 'Salle de reception', 'sal1', 'Pour toute vos reception');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
